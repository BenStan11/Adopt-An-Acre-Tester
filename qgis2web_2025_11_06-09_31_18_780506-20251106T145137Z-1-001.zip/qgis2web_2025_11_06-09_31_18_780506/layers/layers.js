var wms_layers = [];

var format_2025CNPPropertyBoundary2025_cnp_property_boundary_0 = new ol.format.GeoJSON();
var features_2025CNPPropertyBoundary2025_cnp_property_boundary_0 = format_2025CNPPropertyBoundary2025_cnp_property_boundary_0.readFeatures(json_2025CNPPropertyBoundary2025_cnp_property_boundary_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_2025CNPPropertyBoundary2025_cnp_property_boundary_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_2025CNPPropertyBoundary2025_cnp_property_boundary_0.addFeatures(features_2025CNPPropertyBoundary2025_cnp_property_boundary_0);
var lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_2025CNPPropertyBoundary2025_cnp_property_boundary_0, 
                style: style_2025CNPPropertyBoundary2025_cnp_property_boundary_0,
                popuplayertitle: '2025 CNP Property Boundary — 2025_cnp_property_boundary',
                interactive: false,
                title: '<img src="styles/legend/2025CNPPropertyBoundary2025_cnp_property_boundary_0.png" /> 2025 CNP Property Boundary — 2025_cnp_property_boundary'
            });
var format_Lake___River_1 = new ol.format.GeoJSON();
var features_Lake___River_1 = format_Lake___River_1.readFeatures(json_Lake___River_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Lake___River_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Lake___River_1.addFeatures(features_Lake___River_1);
var lyr_Lake___River_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Lake___River_1, 
                style: style_Lake___River_1,
                popuplayertitle: 'Lake___River',
                interactive: false,
                title: '<img src="styles/legend/Lake___River_1.png" /> Lake___River'
            });
var format_heronspur_2 = new ol.format.GeoJSON();
var features_heronspur_2 = format_heronspur_2.readFeatures(json_heronspur_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_heronspur_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_heronspur_2.addFeatures(features_heronspur_2);
var lyr_heronspur_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_heronspur_2, 
                style: style_heronspur_2,
                popuplayertitle: 'heron-spur',
                interactive: true,
                title: '<img src="styles/legend/heronspur_2.png" /> heron-spur'
            });
var format_riverotterway_3 = new ol.format.GeoJSON();
var features_riverotterway_3 = format_riverotterway_3.readFeatures(json_riverotterway_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_riverotterway_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_riverotterway_3.addFeatures(features_riverotterway_3);
var lyr_riverotterway_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_riverotterway_3, 
                style: style_riverotterway_3,
                popuplayertitle: 'river-otter-way',
                interactive: true,
                title: '<img src="styles/legend/riverotterway_3.png" /> river-otter-way'
            });
var format_cnptrailsCNPTrails_4 = new ol.format.GeoJSON();
var features_cnptrailsCNPTrails_4 = format_cnptrailsCNPTrails_4.readFeatures(json_cnptrailsCNPTrails_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_cnptrailsCNPTrails_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_cnptrailsCNPTrails_4.addFeatures(features_cnptrailsCNPTrails_4);
var lyr_cnptrailsCNPTrails_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_cnptrailsCNPTrails_4, 
                style: style_cnptrailsCNPTrails_4,
                popuplayertitle: 'cnp-trails — CNP Trails',
                interactive: false,
                title: '<img src="styles/legend/cnptrailsCNPTrails_4.png" /> cnp-trails — CNP Trails'
            });
var format_accessviapavedtrail_5 = new ol.format.GeoJSON();
var features_accessviapavedtrail_5 = format_accessviapavedtrail_5.readFeatures(json_accessviapavedtrail_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_accessviapavedtrail_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_accessviapavedtrail_5.addFeatures(features_accessviapavedtrail_5);
var lyr_accessviapavedtrail_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_accessviapavedtrail_5, 
                style: style_accessviapavedtrail_5,
                popuplayertitle: 'access-via-paved-trail',
                interactive: true,
                title: '<img src="styles/legend/accessviapavedtrail_5.png" /> access-via-paved-trail'
            });
var format_southaccessviapavedtrail_6 = new ol.format.GeoJSON();
var features_southaccessviapavedtrail_6 = format_southaccessviapavedtrail_6.readFeatures(json_southaccessviapavedtrail_6, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_southaccessviapavedtrail_6 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_southaccessviapavedtrail_6.addFeatures(features_southaccessviapavedtrail_6);
var lyr_southaccessviapavedtrail_6 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_southaccessviapavedtrail_6, 
                style: style_southaccessviapavedtrail_6,
                popuplayertitle: 'south-access-via-paved-trail',
                interactive: false,
                title: '<img src="styles/legend/southaccessviapavedtrail_6.png" /> south-access-via-paved-trail'
            });

lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0.setVisible(true);lyr_Lake___River_1.setVisible(true);lyr_heronspur_2.setVisible(true);lyr_riverotterway_3.setVisible(true);lyr_cnptrailsCNPTrails_4.setVisible(true);lyr_accessviapavedtrail_5.setVisible(true);lyr_southaccessviapavedtrail_6.setVisible(true);
var layersList = [lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0,lyr_Lake___River_1,lyr_heronspur_2,lyr_riverotterway_3,lyr_cnptrailsCNPTrails_4,lyr_accessviapavedtrail_5,lyr_southaccessviapavedtrail_6];
lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', 'PIN': 'PIN', 'GIS_ACRES': 'GIS_ACRES', 'SHEET': 'SHEET', 'BLOCK': 'BLOCK', 'LOT': 'LOT', 'VERDATE': 'VERDATE', 'DIST': 'DIST', 'OWNAM1': 'OWNAM1', 'OWNAM2': 'OWNAM2', 'NAMECO': 'NAMECO', 'STREET': 'STREET', 'CITY': 'CITY', 'STATE': 'STATE', 'ZIP5': 'ZIP5', 'ZIP4': 'ZIP4', 'POWNNM': 'POWNNM', 'CUBOOK': 'CUBOOK', 'CUPAGE': 'CUPAGE', 'DEEDTE': 'DEEDTE', 'DEEDDATE': 'DEEDDATE', 'PLTBK1': 'PLTBK1', 'PPAGE1': 'PPAGE1', 'JURIS': 'JURIS', 'DESCR': 'DESCR', 'SUBDIV': 'SUBDIV', 'TACRES': 'TACRES', 'LOCATE': 'LOCATE', 'STRNUM': 'STRNUM', 'ZONECD': 'ZONECD', 'LANDUSE': 'LANDUSE', 'HMSTCD': 'HMSTCD', 'MKTAREA': 'MKTAREA', 'APPAREA': 'APPAREA', 'SWATER': 'SWATER', 'CWATER': 'CWATER', 'SLPRICE': 'SLPRICE', 'BLDGS': 'BLDGS', 'BLDGVAL': 'BLDGVAL', 'LANDVAL': 'LANDVAL', 'TAXMKTVAL': 'TAXMKTVAL', 'FAIRMKTVAL': 'FAIRMKTVAL', 'ROLLBK': 'ROLLBK', 'TOTTAX': 'TOTTAX', 'ACCTNO': 'ACCTNO', 'PDDATE': 'PDDATE', 'PAIDDATE': 'PAIDDATE', 'CLASS1': 'CLASS1', 'CLASS2': 'CLASS2', 'CLASS3': 'CLASS3', 'SQFEET': 'SQFEET', 'BATHRMS': 'BATHRMS', 'BEDROOMS': 'BEDROOMS', 'HALFBATH': 'HALFBATH', 'RESGRADE': 'RESGRADE', 'GRDADJ': 'GRDADJ', 'BUILD1': 'BUILD1', 'BUILD2': 'BUILD2', 'BUILD3': 'BUILD3', 'BUILD4': 'BUILD4', 'BUILD5': 'BUILD5', 'BUILD6': 'BUILD6', 'OCCUP1': 'OCCUP1', 'OCCUP2': 'OCCUP2', 'OCCUP3': 'OCCUP3', 'OCCUP4': 'OCCUP4', 'OCCUP5': 'OCCUP5', 'OCCUP6': 'OCCUP6', 'COMGRADE1': 'COMGRADE1', 'COMGRADE2': 'COMGRADE2', 'COMGRADE3': 'COMGRADE3', 'COMGRADE4': 'COMGRADE4', 'COMGRADE5': 'COMGRADE5', 'COMGRADE6': 'COMGRADE6', 'TOTFLAREA1': 'TOTFLAREA1', 'TOTFLAREA2': 'TOTFLAREA2', 'TOTFLAREA3': 'TOTFLAREA3', 'TOTFLAREA4': 'TOTFLAREA4', 'TOTFLAREA5': 'TOTFLAREA5', 'TOTFLAREA6': 'TOTFLAREA6', 'RRETCD': 'RRETCD', 'PROPTYPE': 'PROPTYPE', 'IMPROVED': 'IMPROVED', 'STRPRE': 'STRPRE', 'STRTYP': 'STRTYP', 'STRSUF': 'STRSUF', 'layer': 'layer', 'path': 'path', });
lyr_Lake___River_1.set('fieldAliases', {'FEAT_CODE': 'FEAT_CODE', 'NAME': 'NAME', 'LASTUPDATE': 'LASTUPDATE', 'EDITORNAME': 'EDITORNAME', 'CMETHOD': 'CMETHOD', 'CSOURCE': 'CSOURCE', 'ISOURCE': 'ISOURCE', });
lyr_heronspur_2.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_riverotterway_3.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_cnptrailsCNPTrails_4.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_accessviapavedtrail_5.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_southaccessviapavedtrail_6.set('fieldAliases', {'Name': 'Name', 'description': 'description', 'timestamp': 'timestamp', 'begin': 'begin', 'end': 'end', 'altitudeMode': 'altitudeMode', 'tessellate': 'tessellate', 'extrude': 'extrude', 'visibility': 'visibility', 'drawOrder': 'drawOrder', 'icon': 'icon', });
lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', 'PIN': '', 'GIS_ACRES': '', 'SHEET': '', 'BLOCK': '', 'LOT': '', 'VERDATE': '', 'DIST': '', 'OWNAM1': '', 'OWNAM2': '', 'NAMECO': '', 'STREET': '', 'CITY': '', 'STATE': '', 'ZIP5': '', 'ZIP4': '', 'POWNNM': '', 'CUBOOK': '', 'CUPAGE': '', 'DEEDTE': '', 'DEEDDATE': '', 'PLTBK1': '', 'PPAGE1': '', 'JURIS': '', 'DESCR': '', 'SUBDIV': '', 'TACRES': '', 'LOCATE': '', 'STRNUM': '', 'ZONECD': '', 'LANDUSE': '', 'HMSTCD': '', 'MKTAREA': '', 'APPAREA': '', 'SWATER': '', 'CWATER': '', 'SLPRICE': '', 'BLDGS': '', 'BLDGVAL': '', 'LANDVAL': '', 'TAXMKTVAL': '', 'FAIRMKTVAL': '', 'ROLLBK': '', 'TOTTAX': '', 'ACCTNO': '', 'PDDATE': '', 'PAIDDATE': '', 'CLASS1': '', 'CLASS2': '', 'CLASS3': '', 'SQFEET': '', 'BATHRMS': '', 'BEDROOMS': '', 'HALFBATH': '', 'RESGRADE': '', 'GRDADJ': '', 'BUILD1': '', 'BUILD2': '', 'BUILD3': '', 'BUILD4': '', 'BUILD5': '', 'BUILD6': '', 'OCCUP1': '', 'OCCUP2': '', 'OCCUP3': '', 'OCCUP4': '', 'OCCUP5': '', 'OCCUP6': '', 'COMGRADE1': '', 'COMGRADE2': '', 'COMGRADE3': '', 'COMGRADE4': '', 'COMGRADE5': '', 'COMGRADE6': '', 'TOTFLAREA1': '', 'TOTFLAREA2': '', 'TOTFLAREA3': '', 'TOTFLAREA4': '', 'TOTFLAREA5': '', 'TOTFLAREA6': '', 'RRETCD': '', 'PROPTYPE': '', 'IMPROVED': '', 'STRPRE': '', 'STRTYP': '', 'STRSUF': '', 'layer': '', 'path': '', });
lyr_Lake___River_1.set('fieldImages', {'FEAT_CODE': '', 'NAME': '', 'LASTUPDATE': '', 'EDITORNAME': '', 'CMETHOD': '', 'CSOURCE': '', 'ISOURCE': '', });
lyr_heronspur_2.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_riverotterway_3.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_cnptrailsCNPTrails_4.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_accessviapavedtrail_5.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_southaccessviapavedtrail_6.set('fieldImages', {'Name': '', 'description': '', 'timestamp': '', 'begin': '', 'end': '', 'altitudeMode': '', 'tessellate': '', 'extrude': '', 'visibility': '', 'drawOrder': '', 'icon': '', });
lyr_2025CNPPropertyBoundary2025_cnp_property_boundary_0.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', 'PIN': 'no label', 'GIS_ACRES': 'no label', 'SHEET': 'no label', 'BLOCK': 'no label', 'LOT': 'no label', 'VERDATE': 'no label', 'DIST': 'no label', 'OWNAM1': 'no label', 'OWNAM2': 'no label', 'NAMECO': 'no label', 'STREET': 'no label', 'CITY': 'no label', 'STATE': 'no label', 'ZIP5': 'no label', 'ZIP4': 'no label', 'POWNNM': 'no label', 'CUBOOK': 'no label', 'CUPAGE': 'no label', 'DEEDTE': 'no label', 'DEEDDATE': 'no label', 'PLTBK1': 'no label', 'PPAGE1': 'no label', 'JURIS': 'no label', 'DESCR': 'no label', 'SUBDIV': 'no label', 'TACRES': 'no label', 'LOCATE': 'no label', 'STRNUM': 'no label', 'ZONECD': 'no label', 'LANDUSE': 'no label', 'HMSTCD': 'no label', 'MKTAREA': 'no label', 'APPAREA': 'no label', 'SWATER': 'no label', 'CWATER': 'no label', 'SLPRICE': 'no label', 'BLDGS': 'no label', 'BLDGVAL': 'no label', 'LANDVAL': 'no label', 'TAXMKTVAL': 'no label', 'FAIRMKTVAL': 'no label', 'ROLLBK': 'no label', 'TOTTAX': 'no label', 'ACCTNO': 'no label', 'PDDATE': 'no label', 'PAIDDATE': 'no label', 'CLASS1': 'no label', 'CLASS2': 'no label', 'CLASS3': 'no label', 'SQFEET': 'no label', 'BATHRMS': 'no label', 'BEDROOMS': 'no label', 'HALFBATH': 'no label', 'RESGRADE': 'no label', 'GRDADJ': 'no label', 'BUILD1': 'no label', 'BUILD2': 'no label', 'BUILD3': 'no label', 'BUILD4': 'no label', 'BUILD5': 'no label', 'BUILD6': 'no label', 'OCCUP1': 'no label', 'OCCUP2': 'no label', 'OCCUP3': 'no label', 'OCCUP4': 'no label', 'OCCUP5': 'no label', 'OCCUP6': 'no label', 'COMGRADE1': 'no label', 'COMGRADE2': 'no label', 'COMGRADE3': 'no label', 'COMGRADE4': 'no label', 'COMGRADE5': 'no label', 'COMGRADE6': 'no label', 'TOTFLAREA1': 'no label', 'TOTFLAREA2': 'no label', 'TOTFLAREA3': 'no label', 'TOTFLAREA4': 'no label', 'TOTFLAREA5': 'no label', 'TOTFLAREA6': 'no label', 'RRETCD': 'no label', 'PROPTYPE': 'no label', 'IMPROVED': 'no label', 'STRPRE': 'no label', 'STRTYP': 'no label', 'STRSUF': 'no label', 'layer': 'no label', 'path': 'no label', });
lyr_Lake___River_1.set('fieldLabels', {'FEAT_CODE': 'no label', 'NAME': 'no label', 'LASTUPDATE': 'no label', 'EDITORNAME': 'no label', 'CMETHOD': 'no label', 'CSOURCE': 'no label', 'ISOURCE': 'no label', });
lyr_heronspur_2.set('fieldLabels', {'Name': 'inline label - always visible', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_riverotterway_3.set('fieldLabels', {'Name': 'inline label - always visible', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_cnptrailsCNPTrails_4.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_accessviapavedtrail_5.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_southaccessviapavedtrail_6.set('fieldLabels', {'Name': 'no label', 'description': 'no label', 'timestamp': 'no label', 'begin': 'no label', 'end': 'no label', 'altitudeMode': 'no label', 'tessellate': 'no label', 'extrude': 'no label', 'visibility': 'no label', 'drawOrder': 'no label', 'icon': 'no label', });
lyr_southaccessviapavedtrail_6.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});